; ============================================================
;  YOLO Annotator Pro — Inno Setup Script
;  Genera un instalador .exe profesional para Windows
;
;  Requisitos:
;    - Inno Setup 6  (https://jrsoftware.org/isdl.php)
;    - Haber ejecutado build.bat primero (genera dist\YoloAnnotatorPro.exe)
;
;  Compilar:
;    "C:\Program Files (x86)\Inno Setup 6\ISCC.exe" installer.iss
;    (o abrir este archivo con Inno Setup IDE y pulsar F9)
; ============================================================

#define AppName      "YOLO Annotator Pro"
#define AppVersion   "1.0.0"
#define AppPublisher "Tu Nombre o Empresa"
#define AppURL       "https://github.com/tu-usuario/yolo-annotator-pro"
#define AppExeName   "YoloAnnotatorPro.exe"
#define AppID        "{{A1B2C3D4-E5F6-7890-ABCD-EF1234567890}"

[Setup]
; Identificador único de la aplicación (no cambiar después del primer release)
AppId={#AppID}
AppName={#AppName}
AppVersion={#AppVersion}
AppVerName={#AppName} {#AppVersion}
AppPublisher={#AppPublisher}
AppPublisherURL={#AppURL}
AppSupportURL={#AppURL}
AppUpdatesURL={#AppURL}

; Directorio de instalación por defecto
DefaultDirName={autopf}\{#AppName}
DefaultGroupName={#AppName}
AllowNoIcons=no

; Carpeta de salida del instalador
OutputDir=Output
OutputBaseFilename=YoloAnnotatorPro_Setup_{#AppVersion}

; Compresión
Compression=lzma2/ultra64
SolidCompression=yes
LZMAUseSeparateProcess=yes

; Requiere privilegios de administrador para instalar en Program Files
PrivilegesRequired=admin
PrivilegesRequiredOverridesAllowed=dialog

; Apariencia del instalador
WizardStyle=modern
WizardSizePercent=120
SetupIconFile=assets\icon.ico   ; comenta esta línea si no tienes icono
UninstallDisplayIcon={app}\{#AppExeName}
UninstallDisplayName={#AppName}

; Plataforma objetivo
ArchitecturesInstallIn64BitMode=x64compatible
ArchitecturesAllowed=x64compatible

; Licencia (opcional — comenta si no tienes)
; LicenseFile=LICENSE.txt

; Info previa a la instalación (opcional)
; InfoBeforeFile=README.txt

[Languages]
Name: "spanish";    MessagesFile: "compiler:Languages\Spanish.isl"
Name: "english";    MessagesFile: "compiler:Default.isl"

[Tasks]
; Opciones que el usuario puede elegir durante la instalación
Name: "desktopicon";    Description: "Crear acceso directo en el &Escritorio";    GroupDescription: "Accesos directos:"; Flags: unchecked
Name: "quicklaunch";    Description: "Crear acceso directo en la barra de &inicio rápido"; GroupDescription: "Accesos directos:"; Flags: unchecked; OnlyBelowVersion: 6.1; Check: not IsAdminInstallMode

[Files]
; Ejecutable principal
Source: "dist\{#AppExeName}"; DestDir: "{app}"; Flags: ignoreversion

; Si en el futuro cambias a modo --onedir en vez de --onefile,
; descomenta las siguientes líneas y comenta la de arriba:
; Source: "dist\YoloAnnotatorPro\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs

; Archivos adicionales opcionales
; Source: "LICENSE.txt";  DestDir: "{app}"; Flags: ignoreversion
; Source: "README.md";    DestDir: "{app}"; Flags: ignoreversion
; Source: "assets\*";     DestDir: "{app}\assets"; Flags: ignoreversion recursesubdirs

[Icons]
; Acceso directo en el menú Inicio
Name: "{group}\{#AppName}";          Filename: "{app}\{#AppExeName}"
Name: "{group}\Desinstalar {#AppName}"; Filename: "{uninstallexe}"

; Acceso directo en el escritorio (solo si el usuario lo pidió)
Name: "{autodesktop}\{#AppName}";    Filename: "{app}\{#AppExeName}"; Tasks: desktopicon

[Run]
; Ofrecer lanzar la app al terminar la instalación
Filename: "{app}\{#AppExeName}"; \
    Description: "Lanzar {#AppName}"; \
    Flags: nowait postinstall skipifsilent

[UninstallDelete]
; Limpiar archivos que la app crea en su carpeta durante el uso
Type: filesandordirs; Name: "{app}"

[Registry]
; Registrar la app en "Agregar o quitar programas" (Inno lo hace solo,
; pero podemos añadir info extra)
Root: HKLM; Subkey: "Software\{#AppPublisher}\{#AppName}"; \
    ValueType: string; ValueName: "InstallPath"; \
    ValueData: "{app}"; Flags: uninsdeletekey

[Messages]
; Personalizar textos del asistente (español)
spanish.WelcomeLabel1=Bienvenido al asistente de instalación de [name]
spanish.WelcomeLabel2=Este asistente instalará [name/ver] en su equipo.%n%nSe recomienda cerrar todas las aplicaciones antes de continuar.
spanish.FinishedHeadingLabel=Instalación de [name] completada
spanish.FinishedLabel=[name] se ha instalado correctamente en su equipo.
