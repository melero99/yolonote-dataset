# -*- mode: python ; coding: utf-8 -*-
# ============================================================
#  YOLO Annotator Pro — PyInstaller spec
#  Generado para Python 3.10+ / Windows x64
#
#  Uso:
#      pyinstaller yolo_annotator.spec
# ============================================================

import sys
from pathlib import Path

block_cipher = None

# ------------------------------------------------------------------
# Binarios y datos extra que PyInstaller no detecta solo
# ------------------------------------------------------------------
# opencv-python incluye DLLs propias; en Windows suele necesitar
# el directorio completo de cv2.
import cv2 as _cv2
cv2_dir = Path(_cv2.__file__).parent

added_files = [
    # Copia los datos internos de cv2 (haarcascades, etc.)
    (str(cv2_dir / "data"), "cv2/data"),
]

# ------------------------------------------------------------------
# Módulos ocultos (importaciones dinámicas que PyInstaller no ve)
# ------------------------------------------------------------------
hidden = [
    "cv2",
    "PyQt5.sip",
    "PyQt5.QtCore",
    "PyQt5.QtGui",
    "PyQt5.QtWidgets",
    "PyQt5.QtPrintSupport",   # requerido en algunos temas de Qt
]

a = Analysis(
    ["yolo_annotator.py"],
    pathex=[],
    binaries=[],
    datas=added_files,
    hiddenimports=hidden,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[
        # Excluir módulos pesados que no usamos
        "tkinter",
        "matplotlib",
        "scipy",
        "pandas",
        "notebook",
        "IPython",
        "PIL",           # Pillow — no se usa
        "wx",
        "gtk",
        "PySide2",
        "PySide6",
    ],
    win_no_prefer_redirects=False,
    win_private_assemblies=False,
    cipher=block_cipher,
    noarchive=False,
)

pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.zipfiles,
    a.datas,
    [],
    name="YoloAnnotatorPro",
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,              # comprime el exe (requiere UPX instalado, opcional)
    upx_exclude=[
        "vcruntime140.dll",
        "python3*.dll",
    ],
    runtime_tmpdir=None,
    console=False,         # sin ventana de consola negra
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    # icon="assets/icon.ico",   # descomenta si tienes un .ico
)
