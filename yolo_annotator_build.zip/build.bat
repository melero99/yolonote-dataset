@echo off
REM ============================================================
REM  YOLO Annotator Pro — Script de build para Windows
REM  Doble clic para ejecutar, o lanzar desde CMD/PowerShell
REM ============================================================

setlocal enabledelayedexpansion

echo.
echo  =====================================================
echo   YOLO Annotator Pro — Build Script
echo  =====================================================
echo.

REM ── Verificar Python ──────────────────────────────────────────
python --version >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Python no encontrado en PATH.
    echo         Descarga Python 3.10+ desde https://python.org
    pause & exit /b 1
)
for /f "tokens=*" %%v in ('python --version') do echo [OK] %%v


REM ── Instalar / actualizar dependencias ────────────────────────
echo.
echo [1/4] Instalando dependencias de Python...
pip install --upgrade pip --quiet
pip install PyQt5 opencv-python pyinstaller --quiet
if errorlevel 1 (
    echo [ERROR] Fallo al instalar dependencias.
    pause & exit /b 1
)
echo [OK] Dependencias instaladas.


REM ── Limpiar builds anteriores ─────────────────────────────────
echo.
echo [2/4] Limpiando builds anteriores...
if exist build   rmdir /s /q build
if exist dist    rmdir /s /q dist
echo [OK] Limpieza completada.


REM ── Compilar con PyInstaller ──────────────────────────────────
echo.
echo [3/4] Compilando con PyInstaller (puede tardar 1-3 min)...
pyinstaller yolo_annotator.spec --noconfirm
if errorlevel 1 (
    echo [ERROR] Fallo en la compilacion de PyInstaller.
    pause & exit /b 1
)
echo [OK] Compilacion completada.


REM ── Verificar resultado ───────────────────────────────────────
echo.
echo [4/4] Verificando resultado...
if exist "dist\YoloAnnotatorPro.exe" (
    for %%s in ("dist\YoloAnnotatorPro.exe") do (
        set size=%%~zs
        set /a sizeMB=!size! / 1048576
    )
    echo [OK] dist\YoloAnnotatorPro.exe generado ^(!sizeMB! MB^)
) else (
    echo [ERROR] No se encontro el exe en dist\
    pause & exit /b 1
)


REM ── Opcional: compilar instalador con Inno Setup ──────────────
echo.
set INNO_COMPILER="C:\Program Files (x86)\Inno Setup 6\ISCC.exe"
if exist %INNO_COMPILER% (
    echo [INNO] Inno Setup detectado. Compilando instalador...
    %INNO_COMPILER% installer.iss
    if errorlevel 1 (
        echo [WARN] Inno Setup fallo. El exe directo sigue disponible en dist\
    ) else (
        echo [OK] Instalador generado en Output\YoloAnnotatorPro_Setup.exe
    )
) else (
    echo [INFO] Inno Setup no encontrado. Solo se genera el exe portable.
    echo        Para crear el instalador descarga Inno Setup 6 de:
    echo        https://jrsoftware.org/isdl.php
    echo        y vuelve a ejecutar este script.
)

echo.
echo  =====================================================
echo   Build finalizado.
echo   Exe portable:  dist\YoloAnnotatorPro.exe
if exist %INNO_COMPILER% (
echo   Instalador:    Output\YoloAnnotatorPro_Setup.exe
)
echo  =====================================================
echo.
pause
