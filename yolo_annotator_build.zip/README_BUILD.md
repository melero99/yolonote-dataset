# YOLO Annotator Pro — Guía de Build para Windows
## Qué genera este proceso

```
dist\YoloAnnotatorPro.exe          ← exe portable (un solo archivo)
Output\YoloAnnotatorPro_Setup.exe  ← instalador profesional (opcional)
```

---

## Requisitos previos

| Herramienta | Versión mínima | Descarga |
|---|---|---|
| Python | 3.10+ (64-bit) | https://python.org |
| Inno Setup *(opcional)* | 6.x | https://jrsoftware.org/isdl.php |

> **Importante:** Al instalar Python, marca la opción **"Add Python to PATH"**.

---

## Estructura de archivos necesaria

Coloca todos estos archivos en la **misma carpeta**:

```
mi_proyecto\
├── yolo_annotator.py      ← tu script principal
├── yolo_annotator.spec    ← configuración de PyInstaller
├── installer.iss          ← script de Inno Setup
├── build.bat              ← script de build (ejecutar este)
└── assets\
    └── icon.ico           ← icono (opcional, ver nota abajo)
```

---

## Pasos

### Paso 1 — Generar el exe portable

Haz doble clic en **`build.bat`**.

El script hace automáticamente:
1. Instala `PyQt5`, `opencv-python` y `pyinstaller` (si no están)
2. Limpia builds anteriores
3. Compila con PyInstaller
4. Si detecta Inno Setup, genera también el instalador

Al terminar encontrarás:
- `dist\YoloAnnotatorPro.exe` — funciona en cualquier PC Windows sin instalar nada


### Paso 2 — Generar el instalador *(opcional pero recomendado)*

Si quieres un instalador con asistente, acceso directo y desinstalador:

1. Descarga e instala **Inno Setup 6**: https://jrsoftware.org/isdl.php
2. Vuelve a ejecutar `build.bat` (lo detecta automáticamente), **o** abre `installer.iss` con el IDE de Inno Setup y pulsa **F9**

Resultado: `Output\YoloAnnotatorPro_Setup_{version}.exe`

---

## Icono personalizado *(opcional)*

Si quieres un icono propio:

1. Crea o descarga un archivo `.ico` (256×256 recomendado)
2. Guárdalo en `assets\icon.ico`
3. En `yolo_annotator.spec`, descomenta la línea:
   ```python
   # icon="assets/icon.ico",
   ```
   → quitar el `#`
4. En `installer.iss`, la línea `SetupIconFile=assets\icon.ico` ya está activa

Si **no** tienes icono, comenta esa línea en `installer.iss`:
```ini
; SetupIconFile=assets\icon.ico
```

---

## Reducir el tamaño del exe

El exe portable suele pesar **60–100 MB** por las DLLs de Qt y OpenCV.
Para reducirlo:

- **UPX** (compresor de ejecutables): descarga desde https://upx.github.io,
  extrae `upx.exe` y colócalo en la misma carpeta del proyecto.
  PyInstaller lo detecta solo si está en PATH o en la carpeta.

- **Excluir módulos**: el `.spec` ya excluye matplotlib, scipy, Pillow, etc.
  Si usas más librerías no necesarias, añádelas a la lista `excludes`.

---

## Solución de problemas frecuentes

| Síntoma | Causa probable | Solución |
|---|---|---|
| `python` no reconocido | Python no está en PATH | Reinstalar Python con "Add to PATH" |
| El exe abre y se cierra | Error en el script | Ejecuta desde CMD para ver el error |
| `ModuleNotFoundError: cv2` | cv2 no incluido | Añadir `"cv2"` a `hiddenimports` en el `.spec` |
| Ventana negra de consola | `console=True` en el `.spec` | Cambiar a `console=False` |
| Antivirus bloquea el exe | Falso positivo de PyInstaller | Añadir excepción o firmar el exe |
| Inno Setup dice "file not found" | `dist\YoloAnnotatorPro.exe` no existe | Ejecutar `build.bat` primero |

---

## Distribución

Para distribuir la aplicación tienes dos opciones:

**Opción A — Exe portable**
Comparte directamente `dist\YoloAnnotatorPro.exe`. El usuario lo ejecuta sin instalar nada.

**Opción B — Instalador**
Comparte `Output\YoloAnnotatorPro_Setup.exe`. Instala en `Program Files`, crea accesos directos y aparece en "Agregar o quitar programas".

---

## Personalizar el instalador

Edita las primeras líneas de `installer.iss`:

```ini
#define AppName      "YOLO Annotator Pro"
#define AppVersion   "1.0.0"
#define AppPublisher "Tu Nombre o Empresa"
#define AppURL       "https://github.com/tu-usuario/..."
```

Cambia también `AppID` por un GUID único (puedes generarlo en https://guidgenerator.com).
